function nextStep() {
    document.getElementById("app").innerHTML = `
        <h1>ძაან გაბრაზებული და ნაწყენი ხარ ჩემზე?</h1>
        <button class="yes" onclick="nextStep2()">კი!</button>
        <button class="yes" onclick="nextStep2()">ძალიან!</button>
    `;
}

function nextStep2() {
    document.getElementById("app").innerHTML = `
        <h1>შეიძლება გაწყენინე ვხვდები</h1>
        <p>ბოდიშსაც მოვიხდი და შემირიგდი რა <3</p>
        <h3>შემირიგდები? 🙏</h3>
        <button class="yes" onclick="yes()">კი <3 </button>
        <button class="no" id="noBtn" ontouchstart="move()" onmouseover="move()">არა...</button>
    `;
}

function yes() {
    document.getElementById("app").innerHTML = `
        <h1><3333333333</h1>
        <p>სახლთან თუ გამოხვალ კიდე რაღაცას გაჩუქებ <3 :*</p>
    `;
}

function move() {
    let btn = document.getElementById("noBtn");
    let x = Math.random() * (window.innerWidth - 120);
    let y = Math.random() * (window.innerHeight - 60);
    btn.style.left = x + "px";
    btn.style.top = y + "px";
}